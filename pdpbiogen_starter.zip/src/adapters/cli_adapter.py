# src/adapters/cli_adapter.py
import argparse

def run_episode(duration=30, fs=128):
    print(f"Simulated run: duration={duration}s, fs={fs}Hz")
    # placeholder for simulator

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--duration", type=int, default=30)
    parser.add_argument("--fs", type=int, default=128)
    args = parser.parse_args()
    run_episode(args.duration, args.fs)
