#!/usr/bin/env python3
"""src/pdpbiogen/simulator.py
- Synthetic BCI generator (sinusoids + noise)
- Toy biological ODE (2-state)
- Simple agent (hill-climb)
- Saves results to results/
"""
import os, math
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import yaml

os.makedirs('results', exist_ok=True)
np.random.seed(42)

def generate_bci(duration_s=30.0, fs=128):
    t = np.arange(0, duration_s, 1.0/fs)
    signal = 0.9*np.sin(2*math.pi*3*t) + 0.5*np.sin(2*math.pi*10*t)
    signal += 0.2*np.sin(2*math.pi*40*t)
    signal += 0.35*np.random.normal(scale=0.5, size=t.shape)
    return t, signal

def extract_feature_rms(signal, fs=128, window_s=1.0):
    w = int(window_s*fs)
    n = len(signal)//w
    feats = []
    for i in range(n):
        seg = signal[i*w:(i+1)*w]
        feats.append(np.sqrt(np.mean(seg**2)))
    return np.array(feats)

def bio_odes(state, t, u, a=0.8, b=1.0, c=0.5, d=0.3):
    x, y = state
    dxdt = -a*x + b*u
    dydt = -c*y + d*x
    return [dxdt, dydt]

class SimpleAgent:
    def __init__(self, init_u=0.0, step=0.1):
        self.u = init_u
        self.step = step
    def act(self, feat):
        if feat > 0.6:
            self.u -= self.step
        else:
            self.u += self.step
        self.u = float(np.clip(self.u, -2.0, 2.0))
        return self.u

def run_simulation(duration_s=60.0, fs=128, window_s=1.0):
    t, sig = generate_bci(duration_s, fs)
    feats = extract_feature_rms(sig, fs, window_s)
    agent = SimpleAgent(init_u=0.0, step=0.15)
    state = [0.1, 0.1]
    dt = window_s
    ys, us = [], []
    for feat in feats:
        u = agent.act(feat)
        times = np.linspace(0, dt, 25)
        sol = odeint(bio_odes, state, times, args=(u,))
        state = sol[-1]
        ys.append(state[1])
        us.append(u)
    # save
    np.savez('results/simulation.npz', features=feats, y=np.array(ys), u=np.array(us))
    # plots
    plt.figure(figsize=(10,6))
    plt.subplot(3,1,1); plt.plot(t[:fs*10], sig[:fs*10]); plt.title('BCI (first 10s)')
    plt.subplot(3,1,2); plt.plot(feats); plt.title('Feature (RMS)')
    plt.subplot(3,1,3); plt.plot(ys, label='y'); plt.plot(us, label='u'); plt.legend()
    plt.tight_layout(); plt.savefig('results/simulation_summary.png')
    print('Saved results in results/')

if __name__=='__main__':
    run_simulation()
