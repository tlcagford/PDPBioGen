#!/usr/bin/env python3
# src/adapters/cli_adapter.py
import argparse
from pdpbiogen.simulator import generate_bci, extract_feature_rms
from pdpbiogen.agent import SimpleAgent
from pdpbiogen.bio_model import TwoStateModel
import numpy as np
import os
os.makedirs('results', exist_ok=True)

def run_episode(duration=30, fs=128, window_s=1.0):
    t, sig = generate_bci(duration, fs)
    feats = extract_feature_rms(sig, fs, window_s)
    agent = SimpleAgent()
    model = TwoStateModel()
    ys, us = [], []
    for feat in feats:
        u = agent.act(feat)
        state = model.step(u, dt=window_s)
        ys.append(state[1]); us.append(u)
    np.savez('results/cli_episode.npz', features=feats, y=np.array(ys), u=np.array(us))
    print('Saved results/cli_episode.npz')

if __name__=='__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--duration', type=int, default=60)
    p.add_argument('--fs', type=int, default=128)
    p.add_argument('--window', type=float, default=1.0)
    args = p.parse_args()
    run_episode(args.duration, args.fs, args.window)
