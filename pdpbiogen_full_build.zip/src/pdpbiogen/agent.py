# src/pdpbiogen/agent.py
import numpy as np
class SimpleAgent:
    def __init__(self, init_u=0.0, step=0.1):
        self.u = init_u
        self.step = step
    def act(self, feat):
        if feat > 0.6:
            self.u -= self.step
        else:
            self.u += self.step
        self.u = float(np.clip(self.u, -2.0, 2.0))
        return self.u
