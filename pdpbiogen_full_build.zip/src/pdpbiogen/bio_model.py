# src/pdpbiogen/bio_model.py
from scipy.integrate import odeint
def bio_odes(state, t, u, a=0.8, b=1.0, c=0.5, d=0.3):
    x, y = state
    dxdt = -a*x + b*u
    dydt = -c*y + d*x
    return [dxdt, dydt]

class TwoStateModel:
    def __init__(self, init_state=(0.1,0.1)):
        self.state = list(init_state)
    def step(self, u, dt=1.0):
        times = [0, dt]
        sol = odeint(bio_odes, self.state, times, args=(u,))
        self.state = sol[-1].tolist()
        return self.state
