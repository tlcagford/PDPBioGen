# ETHICS.md

PDPBioGen is an experimental research framework. This file describes ethical constraints, governance, and recommended safeguards.

## Key principles
- **Simulation-first:** All included code is simulation-only. Do not use these outputs for clinical decisions.
- **Human oversight:** Any real-data integration or suggestion must include human experts and, where applicable, IRB oversight.
- **Data minimization & consent:** Only use personally-identifiable or health data with explicit informed consent and secure storage.
- **Transparency & reproducibility:** Publish methods, parameters, and evaluation metrics for each experiment.
- **Fail-safe defaults:** Agents / controllers must NOT be allowed to execute actuations on live subjects without layered safeguards and human-in-the-loop confirmations.

## Recommended governance
- Require code reviews for modules that touch real data.
- Require an ethics review before running interventions.
- Maintain an incident response playbook.
