# PDPBioGen — v0.1 (Full Build Starter)

**Parallel Distributed Processing BioGen** — prototype framework for closed-loop BCI ↔ biological-process optimization.
This package provides a runnable simulator, adapters, documentation, CI, and packaging to jumpstart PDPBioGen v0.1.

**Important:** This is simulation-only. No clinical claims. See `ETHICS.md`.

## Quickstart

```bash
# 1) download & unzip
# 2) create venv
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 3) run simulator
python src/pdpbiogen/simulator.py

# 4) or run CLI adapter
python src/adapters/cli_adapter.py --duration 60 --fs 128
```

## What's included
- `src/pdpbiogen/` core modules (simulator, bio model, agent, utils)
- `src/adapters/cli_adapter.py` CLI orchestration
- `notebooks/demo_simulation.ipynb` demo notebook
- `presets/default.yml` experiment presets
- `ETHICS.md`, `architecture.md`, `WHITEPAPER_outline.md`
- `Dockerfile`, `.github/workflows/ci.yml`
- `requirements.txt`

## Next steps
- Replace simulator inputs with real BCI adapter (MNE / LSL)
- Add unit tests and real datasets under `tests/data/`
- Engage academic collaborators for validation
