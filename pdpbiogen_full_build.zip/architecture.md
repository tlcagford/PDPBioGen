# architecture.md

PDPBioGen v0.1 architecture — modular components and interfaces.

Components:
- bci_sim: synthetic time-series generator
- preprocess: feature extraction (windowing, spectral features)
- bio_model: ODE-based toy biological model
- agent: controller / optimizer
- pipeline: orchestrates closed-loop episodes
- adapters: CLI & future hardware adapters (mne, lsl)

Data flow:
bci_sim -> preprocess -> agent -> bio_model -> logger -> metrics

Module interfaces:
- bci_sim.generate(duration_s, fs) -> (t, signal)
- preprocess.extract_features(signal, fs, window_s) -> features (numpy)
- agent.act(features) -> action (float/array)
- bio_model.step(action, dt) -> new_state
