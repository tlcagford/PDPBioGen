# WHITEPAPER_outline.md

Title: PDPBioGen v0.1 — A Simulation Framework for Closed-loop BCI-guided Biological Optimization

Abstract
- Motivation
- Key contributions (simulation framework, modular adapters, reproducible experiments)

Introduction
- Background: BCI, systems biology, closed-loop control
- Related work: adaptive DBS, neural processing toolkits

Methods
- BCI simulation design
- Biological model (ODE description)
- Agent / optimization algorithms
- Experimental protocol & metrics

Results (simulated)
- Example experiments
- Metrics: convergence, robustness to noise

Discussion
- Limitations
- Ethics & safety
- Roadmap

Appendices
- Code usage, parameter tables, reproducibility checklist
