# Usage

Run simulator:
python src/pdpbiogen/simulator.py

Run CLI example:
python src/adapters/cli_adapter.py --duration 60 --fs 128
