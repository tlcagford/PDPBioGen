# CONTRIBUTING.md

Thanks for contributing! Please follow these steps:

- Fork the repo and create branches per feature/bugfix.
- Run tests locally: (none included yet) 
- Open PRs with clear descriptions and reference any issues.
- Be respectful in code reviews.

Label good-first-issues as desired.
